const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  category: {
    type: String,
    required: true
  },
  countInStock: {
    type: Number,
    required: true,
    min: 0
  },
  image: {
    type: String,
    required: true
    // optionally validate URL format here
  },
  isFeatured: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true // automatically adds createdAt and updatedAt
});

module.exports = mongoose.models.Product || mongoose.model('Product', productSchema);