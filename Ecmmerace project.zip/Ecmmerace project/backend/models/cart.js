const mongoose = require('mongoose');

// Schema for individual cart items
const cartItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    default: 1,
    min: 1
  }
});

// Schema for the cart
const cartSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',   // Reference to User model (make sure User model exists)
    required: true,
    unique: true   // One cart per user
  },
  items: [cartItemSchema]   // Array of cart items
}, {
  timestamps: true   // createdAt, updatedAt timestamps
});

module.exports = mongoose.model('Cart', cartSchema);
