const dotenv = require('dotenv');
const connectDB = require('./config/db');
const express = require('express');
const app = express();
dotenv.config();           // Load .env variables
connectDB();               // Connect to MongoDB

// ✅ Middleware to parse JSON request body (must be before routes)
app.use(express.json());

// ✅ Routes
const authRoutes = require('./routes/authRoutes');
const productRoutes = require('./routes/ProductRoutes');
const cartRoutes = require('./routes/cartRoutes'); 
const orderRoutes = require('./routes/orderRoutes');
const paymentRoutes=require('./routes/paymentRoutes')
const userRoutes = require("./routes/userRoutes");
app.use("/api/users", userRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/payment', paymentRoutes);
app.get('/', (req, res) => {
  res.send('API is running...');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
