const express = require('express');
const router = express.Router();
const { processPayment, getPaymentStatus,createPaymentRecord } = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

router.post('/pay', protect, processPayment);
router.get('/pay/status/:paymentId', protect, getPaymentStatus);
router.post('/create', protect, createPaymentRecord);

module.exports = router;
