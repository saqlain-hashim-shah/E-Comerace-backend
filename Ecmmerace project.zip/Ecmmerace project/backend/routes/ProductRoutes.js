const express = require('express');
const router = express.Router();

const {
  createProduct,
  getAllProduct,
  getProductById,
  updateProduct,
  deleteProduct
} = require('../controllers/productController');

// Create a new product (POST)
router.post('/', createProduct);

// Get all products (GET)
router.get('/', getAllProduct);

// Get a product by ID (GET)
router.get('/:id', getProductById);

// Update a product by ID (PUT)
router.put('/:id', updateProduct);

// Delete a product by ID (DELETE)
router.delete('/:id', deleteProduct);

module.exports = router;
