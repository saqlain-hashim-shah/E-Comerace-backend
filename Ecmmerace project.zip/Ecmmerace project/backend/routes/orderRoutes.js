const express = require('express');
const router = express.Router();
const { placeOrder, getAllOrders, getUserOrders } = require('../controllers/orderController');
const { protect, isAdmin } = require('../middleware/authMiddleware');

// Place an order from the cart
router.post('/place', protect, placeOrder);

// Admin: Get all orders
router.get('/all', protect, isAdmin, getAllOrders);

// User: Get their own orders
router.get('/my-orders', protect, getUserOrders);

module.exports = router;
