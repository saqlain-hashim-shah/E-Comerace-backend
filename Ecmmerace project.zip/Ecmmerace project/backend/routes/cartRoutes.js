const express = require('express');
const router = express.Router();
const { addToCart, getCart, removeFromCart } = require('../controllers/cartController');
const { protect } = require('../middleware/authMiddleware');  // your auth middleware

// Add product to cart
router.post('/cart/add', protect, addToCart);

// Get user's cart
router.get('/cart', protect, getCart);

// Remove product from cart
router.delete('/cart/remove', protect, removeFromCart);

module.exports = router;
