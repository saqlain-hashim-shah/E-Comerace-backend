const Stripe = require('stripe');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const Payment = require('../models/payment');

const createPaymentRecord = async (req, res) => {
  try {
    // Usually you’d get these from your client or cart
    const { orderItems, shippingAddress, paymentMethod, itemsPrice, taxPrice, shippingPrice, totalPrice } = req.body;

    if (!orderItems || orderItems.length === 0) {
      return res.status(400).json({ message: 'No order items' });
    }

    const payment = new Payment({
      user: req.user._id, // from your auth middleware
      orderItems,
      shippingAddress,
      paymentMethod,
      itemsPrice,
      taxPrice,
      shippingPrice,
      totalPrice,
      status: 'pending',
    });

    await payment.save();
    res.status(201).json(payment);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create payment record', error: error.message });
  }
};
// POST /api/pay
const processPayment = async (req, res) => {
  try {
    const { paymentId } = req.body;

    const payment = await Payment.findById(paymentId);
    if (!payment) return res.status(404).json({ message: 'Payment record not found' });

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(payment.totalPrice * 100), // cents
      currency: 'usd',
      metadata: { payment_id: payment._id.toString() }
    });

    payment.paymentInfo = {
      id: paymentIntent.id,
      status: paymentIntent.status,
      method: 'stripe'
    };
    payment.status = paymentIntent.status;
    await payment.save();

    res.status(200).json({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Payment processing failed' });
  }
};

// GET /api/pay/status/:paymentId
const getPaymentStatus = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.paymentId);
    if (!payment) return res.status(404).json({ message: 'Payment record not found' });

    const stripePayment = await stripe.paymentIntents.retrieve(payment.paymentInfo.id);

    if (stripePayment.status === 'succeeded') {
      payment.isPaid = true;
      payment.paidAt = new Date();
      payment.status = 'paid';
      await payment.save();
    }

    res.json({ status: stripePayment.status });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Error retrieving payment status' });
  }
};

module.exports = { createPaymentRecord, processPayment, getPaymentStatus };
