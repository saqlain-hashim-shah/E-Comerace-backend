const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Token generator
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '7d'
    });
};

// Register Controller
const register = async (req, res) => {
    try {
        const { Name, Email, Password } = req.body;

        const userExist = await User.findOne({ Email });
        if (userExist) {
            return res.status(400).json({ message: "User already exists" });
        }

        const newUser = await User.create({ Name, Email, Password });

        res.status(201).json({
            _id: newUser._id,
            Name: newUser.Name,
            Email: newUser.Email,
            Token: generateToken(newUser._id)
        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Login Controller
const login = async (req, res) => {
    try {
        const { Email, Password } = req.body;

        const existingUser = await User.findOne({ Email });
        if (existingUser && await existingUser.matchPassword(Password)) {
            res.status(200).json({
                _id: existingUser._id,
                Name: existingUser.Name,
                Email: existingUser.Email,
                Token: generateToken(existingUser._id)
            });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

module.exports = { register, login };
