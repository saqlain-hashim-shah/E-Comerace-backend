const Order = require('../models/order');
const Cart = require('../models/cart');

// ✅ Place an order from the user's cart
const placeOrder = async (req, res) => {
  const userId = req.user._id;

  try {
    // Find user's cart
    const cart = await Cart.findOne({ user: userId }).populate('items.product');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Calculate total price
    const totalPrice = cart.items.reduce((sum, item) => {
      return sum + item.product.price * item.quantity;
    }, 0);

    // Build order cart format
    const orderItems = cart.items.map(item => ({
      productId: item.product._id,
      quantity: item.quantity
    }));

    // Create new order
    const newOrder = new Order({
      userId,
      cart: orderItems,
      totalPrice,
      status: 'pending'
    });

    await newOrder.save();

    // Optionally clear the cart
    cart.items = [];
    await cart.save();

    res.status(201).json({ message: 'Order placed successfully', order: newOrder });
  } catch (err) {
    res.status(500).json({ message: 'Failed to place order', error: err.message });
  }
};

// ✅ Get all orders (admin)
const getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find().populate('userId', 'Name Email').sort({ createdAt: -1 });
    res.status(200).json(orders);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching orders', error: err.message });
  }
};

// ✅ Get orders for a specific user
const getUserOrders = async (req, res) => {
  const userId = req.user._id;

  try {
    const orders = await Order.find({ userId }).sort({ createdAt: -1 });
    res.status(200).json(orders);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching user orders', error: err.message });
  }
};

module.exports = {
  placeOrder,
  getAllOrders,
  getUserOrders
};
